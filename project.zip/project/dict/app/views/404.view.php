<?php $this->view('includes/header',$data) ?>
<?php $this->view('includes/nav',$data) ?>

<div class="container-fluid p-4 text-center">
	<h1>Page not found</h1>
</div>


<?php $this->view('includes/footer',$data) ?>