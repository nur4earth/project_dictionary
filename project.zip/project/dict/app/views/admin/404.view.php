<?php $this->view('admin/admin-header',$data) ?>
	<h1>Page not found</h1>
<?php $this->view('admin/admin-footer',$data) ?>